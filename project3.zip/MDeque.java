package project3;

import java.util.Iterator;
/**
 * Generic MDeque class
 * A linear collection that supports element insertion and removal at three points
 * Front Middle and Back.
 * Has no fixed limits on number of elements it contains
 * This class inherits from Iterable interface and extends Object
 * All pop,push,peek operations are constant time operations
 * @author Kevin Hernandez
 *
 */

public class MDeque<E> extends Object implements Iterable<E> {
	
	/**
	 * This class is an internal class that represents a 
	 * node in the MDeque.
	 * Class stores object E as value and a reference to next and previous nodes
	 * @author Kevin Hernandez
	 *
	 */
	private class Node<T>{
		private E value;
		private Node<E> next;
		private Node<E> prev;
		
		/**
		 * Constructs a new Node object with a value,
		 * a next value and a prev value both of which point to null.
		 * @param Generic value
		 */
		public Node(E val){
			value = val;
			next = null;
			prev = null;
		}
	}
	
	/**
	 * This class is an internal class that represents a 
	 * iterator object that can iterate forward over the MDeque
	 * Class implements Iterator 
	 * @author Kevin Hernandez
	 *
	 */
	
	private class FwdIterator implements Iterator<E>{
		private Node<E> current;
		public FwdIterator(MDeque<E> mDeque) {
			this.current = mDeque.head;
		}
		
		/**
		 *If this iteration has more elements returns true
		 * @return true if iteration has more elements, false if not
		 */
		@Override
		public boolean hasNext() {
			return current != null;
		}
		
		/**
		 *Returns the next element in iteration
		 * @return next element
		 */
		@Override
		public E next() {
			E node = (E) current.value;
			current = current.next;
			return node;
				
			}
		}
	/**
	 * This class is an internal class that represents a 
	 * iterator object that can iterate in reverse over the MDeque
	 * Class implements Iterator 
	 * @author Kevin Hernandez
	 *
	 */
	private class RevIterator implements Iterator<E>{
		private Node<E> current;
		public RevIterator(MDeque<E> mDeque) {
			this.current = mDeque.tail;
		}
		
		/**
		 *If this iteration has more elements returns true
		 * @return true if iteration has more elements, false if not
		 */
		@Override
		public boolean hasNext() {
			return current!= null;
		}
		
		/**
		 *Returns the next element in iteration
		 * @return next element
		 */
		@Override
		public E next() {
			E node = (E) current.value;
			current = current.prev;
			return node;
		}
	}
	
	

	private Node<E> head;
	private Node<E> tail;
	private Node<E> middle;
	private int count;
	
	/**
	 * Constructs a new empty MDeque. 
	 * Empty MDeque has a head middle tail and count which keeps track of size
	 * size of empty TreeList is 0
	 * head and tail both point to null in empty TreeList
	 */
	
	public MDeque(){
		this.head = null;
		this.tail = null;
		this.middle = null;
		this.count = 0;
	}
	
	/**
	 *Returns an iterator over the elements in this mdeque in proper sequence.
	 *The elements will be returned in order from front to back.
	 * @return an iterator over the elements in this mdeque in proper sequence
	 */
	public FwdIterator iterator() {
		return new FwdIterator(this);
	}
	/**
	 * Returns an iterator over the elements in this mdeque in reverse sequential order.
	 *The elements will be returned in order from back to front
	 * @return an iterator over the elements in this mdeque in reverse sequence
	 */
	public RevIterator reverseIterator(){
		return new RevIterator(this);
	}
	
	/**
	 * retrieves first element of this mdeque
	 * @return front element or "head" of this mdeque, null if empty
	 */
	
	public E peekFront() {
		if(this.tail == null) {
			return null;
		}
		return this.head.value;
	}

	/**
	 * retrieves middle element of this mdeque
	 * @return middle element of this mdeque, null if empty
	 */
	public E peekMiddle() {
		if (this.size() == 0) {
			return null;
		}
		return this.middle.value;
	}
	
	/**
	 * retrieves back element of this mdeque
	 * @return back element or "tail" of this mdeque, null if empty
	 */
	public E peekBack() {
		if(this.size()== 0) {
			return null;
		}
		return this.tail.value;
	}
	
	/**
	 * reverses mdeque by reordering nodes in mdeque to be in reverse order
	 * changes head middle and tail value accordingly
	 */
	public void reverse() {
		Node<E> n = null;
		Node<E> current = this.head;
		//iterate through mdeque
		while(current!= null) {
			n = current.prev;
			current.prev = current.next;
			current.next = n;
			current = current.prev;
		}
		//change head and tail values
		Node<E> t = this.head;
		this.head = this.tail;
		this.tail = t;
		//change middle value if even
		if(this.count % 2 == 0) {
			this.middle= this.middle.prev;
		if (n != null) {
			this.head= n.prev;
		}
		}
	}
	
	/**
	 * retrieves and removes back element of this mdeque
	 * handles 3 different scenarios when removing from back
	 * @return back element or "tail" of this mdeque, null if empty
	 */
	public E popBack() {
		//handles cases when MDeque is already empty
		if(this.tail == null) {
			return null;
		}
		//del is node to be popped, n will be the new tail
		Node<E> del = this.tail;
		Node <E> n = this.tail.prev;
		// handles cases where once del is removed MDeque is empty
		if(n == null) {
			this.head = n;
			this.tail = n;
			this.middle = n;
			this.count --;
			return del.value;
		}
		//handles all other cases
		n.next = null;
		this.tail = n;
		this.count --;
		if((this.count % 2) != 0) {
			this.middle = this.middle.prev;

		}
		return del.value;
	}
	
	/**
	 * retrieves and removes front element of this mdeque
	 * handles 3 different scenarios when removing from front
	 * @return back element or "head" of this mdeque, null if empty
	 */
	public E popFront() {
		// handles cases when MDeque is already empty
		if(this.head == null) {
			return null;
		}
		//del is node to be popped, n will be the new head 
		Node <E> del = this.head;
		Node<E> n = this.head.next;
		//handles case where once del is removed MDeque is empty
		if(n == null) {
			this.head = n;
			this.tail = n;
			this.middle = n;
			this.count --;
			return del.value;
		}
		//handles all other cases
		this.head = del.next;
		this.head.prev = null;
		this.count --;
		if((this.count % 2) == 0) {
			this.middle = this.middle.next;
		}
		
		return del.value;
		
	}
	
	/**
	 * retrieves and removes middle element of this mdeque
	 * handles 4 different scenarios when removing from back
	 * Middle changes based on if mdeque size is even or odd
	 * keeps track of middle accordingly
	 * @return middle element of this mdeque, null if empty
	 */
	public E popMiddle() {
		//handles empty MDeque
		if(this.size() == 0) {
			return null;
		}
		//del is node to be popped delnext and delprev are nodes surrounding it
		//one of delnext or delprev will be the new middle
		Node<E> del = this.middle;
		Node<E> delnext = this.middle.next;
		Node<E> delprev = this.middle.prev;
		//handles MDeque size 1
		if (this.size() == 1) {
			this.head = null;
			this.middle = null;
			this.tail = null;
			this.count --;
			return del.value;
		}
		//handles MDeque size 2
		if(this.size() == 2) {
			this.middle = delprev;
			this.tail = delprev;
			delprev.next = null;
			this.count --;
			return del.value;
			
		}
		//handles any other size MDeque 
		else {
			//handles odd MDeques
			if((this.size()%2) == 0 && this.size()!=2) {
				delprev.next = delnext;
				delnext.prev = delprev;
				this.middle = del.prev;
				this.count--;
				return del.value;
			}
			//handles Even MDeque
			else {
				delprev.next = delnext;
				delnext.prev = delprev;
				this.middle = del.next;
				this.count--;
			}
			return del.value;
		}
		
		
}
	/**
	 * Inserts the specified item at the back of this mdeque
	 * handles 2 different scenarios when adding from back
	 * @param item- the element to add
	 * @throws IllegalArgumentException if item is null
	 */
	public void pushBack(E item) {
		Node<E> n = new Node<E>(item);
		if (item == null) {
			throw new IllegalArgumentException("item cannot be null");
		}
		//handles empty MDeque, sets head tail and middle to n
		if (this.head == null) {
			n.prev = null;
			n.next = null;
			this.head = n;
			this.tail = n;
			this.middle = n;
			this.count ++;
		}
		//handles all other cases, sets tail to n
		else {
			//new node is added to end of list
			this.tail.next = n;
			// new nodes previous element is set to tail
			n.prev = this.tail;
			// tail is now set to the new node
			this.tail = n;
			// new node which is now the new tail has
			// its next attribute set to null
			this.tail.next = null;
			this.count ++;
			if((this.count % 2) == 0) {
				this.middle = this.middle.next;
				
			}
		}
		
		
	}
	/**
	 * Inserts the specified item at the front of this mdeque
	 * handles 2 different scenarios when adding from front
	 * @param item- the element to add
	 * @throws IllegalArgumentException if item is null
	 */
	public void pushFront(E item) {
		if (item == null) {
				throw new IllegalArgumentException("item cannot be null");
		}
		Node<E> n = new Node<E>(item);
		//handles empty MDeque, makes new Node the head middle and tail
		if (this.head == null) {
			n.next = null;
			n.prev = null;
			this.tail = n;
			this.head = n;
			this.middle = n;
			this.count++;
		}
		//handles all other cases, makes new Node head of MDeque
		else {
			n.next = this.head;
			n.prev = null;
			this.head.prev = n;
			this.head = n;
			this.count ++;
			if((this.count % 2) != 0) {
				this.middle = this.middle.prev;
			}
		}
	}
	
	/**
	 * Inserts the specified item at the middle of this mdeque
	 * handles 4 different scenarios when adding from middle
	 * middle depends on if mdeque is even or odd sized and
	 * is assigned accordingly.
	 * @param item- the element to add
	 * @throws IllegalArgumentException if item is null
	 */
	public void pushMiddle(E item) {
		if (item == null) {
			throw new IllegalArgumentException("item cannot be null");
		}
		Node<E> n = new Node<E>(item);
		//handles case of empty MDeque
		if(this.size() == 0) {
			n.next = null;
			n.prev = null;
			this.head = n;
			this.head.next = null;
			this.tail = n;
			this.middle = n;
			this.count ++;
		}
		//handles case of MDeque of size 1
		else if (this.size() == 1) {
			this.tail.next = n;
			n.prev = this.tail;
			this.tail = n;
			tail.next = null;
			this.middle = n;
			this.count ++;
		}
		//handles even MDeques that are not empty
		else if ((this.size() %2) == 0 && this.size() != 0) {
			n.next = this.middle;
			n.prev = this.middle.prev;
			this.middle.prev.next = n;
			this.middle.prev = n;
			this.middle = n;
			this.count++;
			}
		//handles odd MDeques that are not size 1
		else if((this.size() %2 !=0) && this.size()!= 1) {
			n.next = this.middle.next;
			n.prev = this.middle;
			this.middle.next.prev = n;
			this.middle.next = n;
			this.middle = n;
			this.count++;
		}
	}
	/**
	 * returns the number of elements in this mdeque
	 * @return number of elements in this mdeque
	 */
	public int size() {
		return this.count;
	}
	
	/**
	 * method that helps toString be implemented recursively
	 * is given a node and a string and adds value of node to the string
	 * given in its parameter. Calls itself again until there are no more nodes
	 * returns new string with second square bracket and commas to match formatting
	 * @param node and string 
	 * @return String representation of mdeque
	 */
	public String tempString(Node<E> n, String s) {
			//last element; adds ] to string and returns string
			if (n == null){
				s += "]";
				return s;
			}
			// second to last element does not get a comma in front
			if(n.next == null) {
				s += n.value;
			}
			//adds element to string with comma in front
			else {
				s += n.value;
				s += ", ";
			}
			return tempString(n.next, s);
		}
	
	
	/**
	 * Returns the string representation of this MDeque
	 * The string representation consists of a list of the collection's elements in the order they are returned by its iterator,
	 * enclosed in square brackets ("[]"). Adjacent elements are separated by the characters ", " (comma and space).
	 * Creates an empty string and adds one square bracket
	 * calls tempString to add node values to the empty string 
	 * @returns the string representation of this MDeque
	 */
	@Override
	public String toString() {
		String list = "[";
		Node<E> current = this.head;
		//case of empty mdeque 
		if (current == null) {
			list += "";
			return tempString(current,list);
			
		}
		//all other cases 
		else {
			return tempString(current, list);
		}
	}
}
